const { body, validationResult } = require('express-validator');

// Validation rules array — used for both POST and PUT
const contactValidationRules = [
  // ── First Name ──
  body('firstName')
    .trim()
    .notEmpty().withMessage('First name is required')
    .isLength({ min: 2, max: 50 }).withMessage('First name: 2–50 characters')
    .matches(/^[a-zA-Z\s'-]+$/).withMessage('First name: letters only'),

  // ── Last Name ──
  body('lastName')
    .trim()
    .notEmpty().withMessage('Last name is required')
    .isLength({ min: 2, max: 50 }).withMessage('Last name: 2–50 characters')
    .matches(/^[a-zA-Z\s'-]+$/).withMessage('Last name: letters only'),

  // ── Email ──
  body('email')
    .trim()
    .notEmpty().withMessage('Email is required')
    .isEmail().withMessage('Please enter a valid email')
    .normalizeEmail(),

  // ── Phone (optional but validated if provided) ──
  body('phone')
    .optional({ checkFalsy: true })
    .trim()
    .matches(/^[+]?[\d\s\-\(\)]{10,15}$/).withMessage('Phone: 10–15 digits'),

  // ── About (optional, max 500 chars) ──
  body('about')
    .optional({ checkFalsy: true })
    .trim()
    .isLength({ max: 500 }).withMessage('About cannot exceed 500 characters')
];

// Middleware that checks results and returns errors if any
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    // Return all error messages as an array
    return res.status(422).json({
      message: 'Validation failed',
      errors: errors.array().map(e => ({
        field:   e.path,
        message: e.msg
      }))
    });
  }
  next();
};

module.exports = { contactValidationRules, handleValidationErrors };