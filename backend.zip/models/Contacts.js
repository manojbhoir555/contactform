
const mongoose = require('mongoose');

const contactSchema = new mongoose.Schema(
  {
    firstName: {
      type:     String,
      required: [true, 'First name is required'],
      trim:     true,
      minlength: [2, 'First name must be at least 2 characters'],
      maxlength: [50, 'First name cannot exceed 50 characters'],
      match: [/^[a-zA-Z\s'-]+$/, 'First name can only contain letters']
    },
    lastName: {
      type:     String,
      required: [true, 'Last name is required'],
      trim:     true,
      minlength: [2, 'Last name must be at least 2 characters'],
      maxlength: [50, 'Last name cannot exceed 50 characters'],
      match: [/^[a-zA-Z\s'-]+$/, 'Last name can only contain letters']
    },
    email: {
      type:     String,
      required: [true, 'Email is required'],
      unique:   true,           // No duplicate emails
      lowercase:true,
      trim:     true,
      match: [
        /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
        'Please enter a valid email address'
      ]
    },
    country: {
      type:    String,
      trim:    true,
      default: ''
    },
    phone: {
      type:  String,
      trim:  true,
      match: [
        /^[+]?[\d\s\-\(\)]{10,15}$/,
        'Please enter a valid phone number (10-15 digits)'
      ],
      default: ''
    },
    about: {
      type:      String,
      trim:      true,
      maxlength: [500, 'About cannot exceed 500 characters'],
      default:   ''
    }
  },
  {
    timestamps: true  // Adds createdAt and updatedAt automatically
  }
);

// Index on email for faster lookups + enforces uniqueness at DB level
//contactSchema.index({ email: 1 });

module.exports = mongoose.model('Contacts', contactSchema);
