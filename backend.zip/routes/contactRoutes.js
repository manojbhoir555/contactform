const express = require('express');
const router  = express.Router();
const Contact = require('../models/Contacts');
const { contactValidationRules, handleValidationErrors } =
  require('../middleware/validateContact');

// ─────────────────────────────────────────────
// GET /api/contacts — Fetch all contacts
// ─────────────────────────────────────────────
router.get('/', async (req, res) => {
  try {
    const contacts = await Contact.find().sort({ createdAt: -1 });
    res.json({ success: true, count: contacts.length, contacts });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─────────────────────────────────────────────
// GET /api/contacts/:id — Fetch single contact
// ─────────────────────────────────────────────
router.get('/:id', async (req, res) => {
  try {
    const contact = await Contact.findById(req.params.id);
    if (!contact)
      return res.status(404).json({ success: false, message: 'Contact not found' });
    res.json({ success: true, contact });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─────────────────────────────────────────────
// POST /api/contacts — Create new contact
// Applies: validation rules → error handler → route
// ─────────────────────────────────────────────
router.post(
  '/',
  contactValidationRules,    // Run validation rules
  handleValidationErrors,    // Return errors if any
  async (req, res) => {      // Only reaches here if valid
    try {
      // Check for duplicate email
      const exists = await Contact.findOne({ email: req.body.email });
      if (exists)
        return res.status(409).json({
          success: false,
          message: 'Conflict',
          errors: [{ field: 'email', message: 'This email is already registered' }]
        });

      const contact = await Contact.create(req.body);
      res.status(201).json({ success: true, contact });
    } catch (err) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

// ─────────────────────────────────────────────
// PUT /api/contacts/:id — Update contact
// ─────────────────────────────────────────────
router.put(
  '/:id',
  contactValidationRules,
  handleValidationErrors,
  async (req, res) => {
    try {
      // Check if another contact already uses this email
      const duplicate = await Contact.findOne({
        email: req.body.email,
        _id: { $ne: req.params.id }  // Exclude current contact
      });
      if (duplicate)
        return res.status(409).json({
          success: false,
          errors: [{ field: 'email', message: 'Email already used by another contact' }]
        });

      const updated = await Contact.findByIdAndUpdate(
        req.params.id,
        req.body,
        { new: true, runValidators: true }  // runValidators re-checks schema rules
      );
      if (!updated)
        return res.status(404).json({ success: false, message: 'Contact not found' });

      res.json({ success: true, contact: updated });
    } catch (err) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

// ─────────────────────────────────────────────
// DELETE /api/contacts/:id — Delete contact
// ─────────────────────────────────────────────
router.delete('/:id', async (req, res) => {
  try {
    const deleted = await Contact.findByIdAndDelete(req.params.id);
    if (!deleted)
      return res.status(404).json({ success: false, message: 'Contact not found' });
    res.json({ success: true, message: 'Contact deleted successfully' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;