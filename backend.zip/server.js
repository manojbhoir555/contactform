
  const express  = require('express');
const mongoose = require('mongoose');
const cors     = require('cors');
require('dotenv').config();

const app = express();

// Middleware
app.use(cors({ origin: 'http://localhost:3000' }));
app.use(express.json());

// Routes
app.use('/api/contacts', require('./routes/contactRoutes'));

// Health check endpoint
app.get('/', (req, res) => res.json({ status: 'Contact Manager API running ✅' }));

// 404 handler for unknown routes
app.use((req, res) => res.status(404).json({ message: 'Route not found' }));

// Connect to MongoDB, then start the server
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => {
    console.log('✅ MongoDB connected');
    app.listen(process.env.PORT || 5000, () =>
      console.log(`🚀 API at http://localhost:${process.env.PORT}`)
    );
  })
  .catch((err) => console.error('❌ DB Error:', err));