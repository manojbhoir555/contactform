export default function ContactCard({ contact, onEdit, onDelete }) {
  const { firstName, lastName, email, phone, country, about } = contact;

  // Generate initials for avatar: "John Doe" → "JD"
  const initials =
    (firstName[0] || '').toUpperCase() +
    (lastName[0] || '').toUpperCase();

  // Generate a consistent color from the name
  const colors = ['#2563eb','#7c3aed','#0891b2','#059669','#d97706','#dc2626'];
  const colorIdx = (firstName.charCodeAt(0) + lastName.charCodeAt(0)) % colors.length;

  return (
    <div className="contact-card">
      <div className="card-top">
        <div className="card-avatar"
          style={{ background: colors[colorIdx] }}>
          {initials}
        </div>
        <div className="card-actions">
          <button className="card-btn edit-btn" onClick={() => onEdit(contact)}
            title="Edit contact">✏️</button>
          <button className="card-btn del-btn"  onClick={() => onDelete(contact._id)}
            title="Delete contact">🗑️</button>
        </div>
      </div>

      <div className="card-body">
        <h3 className="card-name">{firstName} {lastName}</h3>
        <p className="card-email">📧 {email}</p>
        {phone   && <p className="card-meta">📱 {phone}</p>}
        {country && <p className="card-meta">🌍 {country}</p>}
        {about   && <p className="card-about">{about}</p>}
      </div>
    </div>
  );
}