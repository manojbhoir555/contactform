import { useState, useEffect } from 'react';
import FormField from './FormFields';

const COUNTRIES = [
  '', 'India', 'United States', 'United Kingdom', 'Canada',
  'Australia', 'Germany', 'France', 'Japan', 'Singapore', 'UAE', 'Other'
];

const EMPTY_FORM = {
  firstName: '', lastName: '', email: '',
  country: '',   phone: '',    about: ''
};

/**
 * ContactForm — REUSABLE for both Add and Edit
 *
 * Props:
 *   initialData  — contact object when editing, undefined when adding
 *   onSubmit     — called with form data when form is valid
 *   onCancel     — called when user clicks Cancel
 *   loading      — shows "Saving..." state on button
 *   serverErrors — errors returned from the API (e.g. duplicate email)
 */
export default function ContactForm({
  initialData, onSubmit, onCancel, loading, serverErrors = []
}) {
  const isEditMode = !!initialData?._id;

  // Initialize form — edit mode fills with existing data
  const [form, setForm] = useState(initialData || EMPTY_FORM);

  // Reset when initialData changes (e.g. user clicks Edit on different contact)
  useEffect(() => {
    setForm(initialData || EMPTY_FORM);
    setErrors({});
  }, [initialData]);

  const [errors, setErrors] = useState({});

  // ── Frontend Validation ──────────────────────────
  const validate = () => {
    const errs = {};

    if (!form.firstName.trim())
      errs.firstName = 'First name is required';
    else if (form.firstName.trim().length < 2)
      errs.firstName = 'At least 2 characters required';
    else if (/[^a-zA-Z\s'-]/.test(form.firstName))
      errs.firstName = 'Letters only';

    if (!form.lastName.trim())
      errs.lastName = 'Last name is required';
    else if (form.lastName.trim().length < 2)
      errs.lastName = 'At least 2 characters required';
    else if (/[^a-zA-Z\s'-]/.test(form.lastName))
      errs.lastName = 'Letters only';

    if (!form.email.trim())
      errs.email = 'Email is required';
    else if (!/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(form.email))
      errs.email = 'Enter a valid email address';

    if (form.phone && !/^[+]?[\d\s\-\(\)]{10,15}$/.test(form.phone))
      errs.phone = 'Enter a valid phone number (10–15 digits)';

    if (form.about.length > 500)
      errs.about = 'Maximum 500 characters';

    return errs;
  };

  // Merge server-side errors (e.g. duplicate email) into errors state
  useEffect(() => {
    if (serverErrors.length) {
      const se = {};
      serverErrors.forEach(e => { se[e.field] = e.message; });
      setErrors(prev => ({ ...prev, ...se }));
    }
  }, [serverErrors]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
    // Clear error for field as user types
    if (errors[name]) setErrors(prev => ({ ...prev, [name]: '' }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) {
      setErrors(errs);
      return;
    }
    onSubmit(form);  // Pass validated data up to parent
  };

  return (
    <form className="contact-form" onSubmit={handleSubmit} noValidate>
      <h2 className="form-title">
        {isEditMode ? '✏️ Edit Contact' : '➕ New Contact'}
      </h2>

      <div className="form-row">
        <FormField label="First Name" name="firstName"
          value={form.firstName} onChange={handleChange}
          error={errors.firstName} required placeholder="John" />

        <FormField label="Last Name" name="lastName"
          value={form.lastName} onChange={handleChange}
          error={errors.lastName} required placeholder="Doe" />
      </div>

      <FormField label="Email Address" name="email" type="email"
        value={form.email} onChange={handleChange}
        error={errors.email} required placeholder="john@example.com" />

      <div className="form-row">
        <FormField label="Country" name="country"
          value={form.country} onChange={handleChange} error={errors.country}>
          <select id="country" name="country"
            value={form.country} onChange={handleChange}
            className="field-input">
            <option value="">— Select Country —</option>
            {COUNTRIES.filter(c => c).map(c =>
              <option key={c} value={c}>{c}</option>
            )}
          </select>
        </FormField>

        <FormField label="Phone Number" name="phone" type="tel"
          value={form.phone} onChange={handleChange}
          error={errors.phone} placeholder="+91 9876543210" />
      </div>

      <FormField label="About" name="about"
        value={form.about} onChange={handleChange} error={errors.about}>
        <textarea
          id="about" name="about"
          value={form.about} onChange={handleChange}
          placeholder="A short bio or note about this contact..."
          maxLength={500} rows={4}
          className={`field-input field-textarea ${errors.about ? 'field-error-border' : ''}`}
        />
        <div className="char-count"></div>
      </FormField>

      <div className="form-actions">
        <button type="button" className="btn-cancel" onClick={onCancel}>
          Cancel
        </button>
        <button type="submit" className="btn-submit" disabled={loading}>
          {loading ? 'Saving...' : isEditMode ? 'Update Contact' : 'Add Contact'}
        </button>
      </div>
    </form>
  );
}