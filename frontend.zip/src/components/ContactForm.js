import { useState, useEffect } from 'react';
import FormField from './FormFields';
 
const COUNTRIES = [
  '', 'India', 'United States', 'United Kingdom', 'Canada',
  'Australia', 'Germany', 'France', 'Japan', 'Singapore', 'UAE', 'Other'
];
 
// Safe default — every field is guaranteed to be a string
const EMPTY_FORM = {
  firstName: '',
  lastName: '',
  email: '',
  country: '',
  phone: '',
  about: ''
};
 
// Merge initialData safely so no field is ever undefined/null
const buildForm = (data) => ({
  firstName: data?.firstName ?? '',
  lastName:  data?.lastName  ?? '',
  email:     data?.email     ?? '',
  country:   data?.country   ?? '',
  phone:     data?.phone     ?? '',
  about:     data?.about     ?? ''
});
 
/**
 * ContactForm — REUSABLE for both Add and Edit
 *
 * Props:
 *   initialData  — contact object when editing, {} or undefined when adding
 *   onSubmit     — called with form data when form is valid
 *   onCancel     — called when user clicks Cancel
 *   loading      — shows "Saving..." state on button
 *   serverErrors — errors returned from the API (e.g. duplicate email)
 */
export default function ContactForm({
  initialData,
  onSubmit,
  onCancel,
  loading,
  serverErrors = []
}) {
  const isEditMode = !!(initialData?._id);
 
  const [form, setForm] = useState(() => buildForm(initialData));
  const [errors, setErrors] = useState({});
 
  // Re-initialize when initialData changes (switching between contacts)
  useEffect(() => {
    setForm(buildForm(initialData));
    setErrors({});
  }, [initialData]);
 
  // Merge server-side errors (e.g. duplicate email) into local errors
  useEffect(() => {
    if (serverErrors && serverErrors.length > 0) {
      const se = {};
      serverErrors.forEach(e => { se[e.field] = e.message; });
      setErrors(prev => ({ ...prev, ...se }));
    }
  }, [serverErrors]);
 
  // ── Frontend Validation ──────────────────────────────────
  const validate = () => {
    const errs = {};
 
    // First Name
    const fn = (form.firstName || '').trim();
    if (!fn)
      errs.firstName = 'First name is required';
    else if (fn.length < 2)
      errs.firstName = 'At least 2 characters required';
    else if (/[^a-zA-Z\s''-]/.test(fn))
      errs.firstName = 'Letters only';
 
    // Last Name
    const ln = (form.lastName || '').trim();
    if (!ln)
      errs.lastName = 'Last name is required';
    else if (ln.length < 2)
      errs.lastName = 'At least 2 characters required';
    else if (/[^a-zA-Z\s''-]/.test(ln))
      errs.lastName = 'Letters only';
 
    // Email
    const em = (form.email || '').trim();
    if (!em)
      errs.email = 'Email is required';
    else if (!/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/.test(em))
      errs.email = 'Enter a valid email address';
 
    // Phone (optional)
    const ph = (form.phone || '').trim();
    if (ph && !/^[+]?[\d\s\-()]{10,15}$/.test(ph))
      errs.phone = 'Enter a valid phone number (10–15 digits)';
 
    // About (optional, max 500)
    if ((form.about || '').length > 500)
      errs.about = 'Maximum 500 characters';
 
    return errs;
  };
 
  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
    // Clear the error for this field as the user types
    if (errors[name]) setErrors(prev => ({ ...prev, [name]: '' }));
  };
 
  const handleSubmit = (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }
    onSubmit(form);
  };
 
  return (
    <form className="contact-form" onSubmit={handleSubmit} noValidate>
      <h2 className="form-title">
        {isEditMode ? '✏️ Edit Contact' : '➕ New Contact'}
      </h2>
 
      <div className="form-row">
        <FormField
          label="First Name" name="firstName"
          value={form.firstName} onChange={handleChange}
          error={errors.firstName} required placeholder="John"
        />
        <FormField
          label="Last Name" name="lastName"
          value={form.lastName} onChange={handleChange}
          error={errors.lastName} required placeholder="Doe"
        />
      </div>
 
      <FormField
        label="Email Address" name="email" type="email"
        value={form.email} onChange={handleChange}
        error={errors.email} required placeholder="john@example.com"
      />
 
      <div className="form-row">
        <FormField
          label="Country" name="country"
          value={form.country} onChange={handleChange}
          error={errors.country}
        >
          <select
            id="country" name="country"
            value={form.country} onChange={handleChange}
            className="field-input"
          >
            <option value="">— Select Country —</option>
            {COUNTRIES.filter(c => c).map(c => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </FormField>
 
        <FormField
          label="Phone Number" name="phone" type="tel"
          value={form.phone} onChange={handleChange}
          error={errors.phone} placeholder="+91 9876543210"
        />
      </div>
 
      <FormField
        label="About" name="about"
        value={form.about} onChange={handleChange}
        error={errors.about}
      >
        <textarea
          id="about" name="about"
          value={form.about} onChange={handleChange}
          placeholder="A short bio or note about this contact..."
          maxLength={500} rows={4}
          className={`field-input field-textarea ${errors.about ? 'field-error-border' : ''}`}
        />
        <div className="char-count">{(form.about || '').length}/500</div>
      </FormField>
 
      <div className="form-actions">
        <button type="button" className="btn-cancel" onClick={onCancel}>
          Cancel
        </button>
        <button type="submit" className="btn-submit" disabled={loading}>
          {loading ? 'Saving...' : isEditMode ? 'Update Contact' : 'Add Contact'}
        </button>
      </div>
    </form>
  );
}
 