// A reusable wrapper for any form field — label + input + error message
export default function FormField({
  label, name, type = 'text', value, onChange,
  error, required, placeholder, children, maxLength
}) {
  return (
    <div className="form-field">
      <label htmlFor={name} className="field-label">
        {label}
        {required && <span className="required-star"> *</span>}
      </label>

      {/* Render children (for select/textarea) or a normal input */}
      {children ? (
        children
      ) : (
        <input
          id={name}
          name={name}
          type={type}
          value={value}
          onChange={onChange}
          placeholder={placeholder}
          maxLength={maxLength}
          className={`field-input ${error ? 'field-error-border' : ''}`}
        />
      )}

      {error && <span className="field-error-msg">⚠ {error}</span>}
    </div>
  );
}