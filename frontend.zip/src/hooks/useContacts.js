import { useState, useEffect, useCallback } from 'react';
import axios from 'axios';

const API = 'http://localhost:5000/api/contacts';

export default function useContacts() {
  const [contacts,    setContacts]    = useState([]);
  const [loading,     setLoading]     = useState(false);
  const [saving,      setSaving]      = useState(false);
  const [error,       setError]       = useState('');
  const [serverErrors,setServerErrors] = useState([]);

  const fetchAll = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await axios.get(API);
      setContacts(data.contacts);
    } catch {
      setError('Failed to load contacts');
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchAll(); }, [fetchAll]);

  const createContact = async (data) => {
    setSaving(true); setServerErrors([]);
    try {
      await axios.post(API, data);
      await fetchAll();
      return true;
    } catch (err) {
      setServerErrors(err.response?.data?.errors || []);
      return false;
    } finally { setSaving(false); }
  };

  const updateContact = async (id, data) => {
    setSaving(true); setServerErrors([]);
    try {
      await axios.put(`${API}/${id}`, data);
      await fetchAll();
      return true;
    } catch (err) {
      setServerErrors(err.response?.data?.errors || []);
      return false;
    } finally { setSaving(false); }
  };

  const deleteContact = async (id) => {
    if (!window.confirm('Delete this contact? This cannot be undone.')) return;
    await axios.delete(`${API}/${id}`);
    fetchAll();
  };

  return { contacts, loading, saving, error, serverErrors,
           createContact, updateContact, deleteContact };
}