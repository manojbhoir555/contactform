import { useState } from 'react';
import useContacts  from '../hooks/useContacts';
import ContactCard  from '../components/ContactCard';
import ContactForm  from '../components/ContactForm';

export default function ContactsPage() {
  const {
    contacts, loading, saving, serverErrors,
    createContact, updateContact, deleteContact
  } = useContacts();

  // null = modal closed, undefined = Add mode, contact obj = Edit mode
  const [modalData, setModalData] = useState(null);
  const isModalOpen = modalData !== null;

  const openAdd    = () => setModalData({});        // empty = Add mode
  const openEdit   = (c) => setModalData(c);        // contact obj = Edit mode
  const closeModal = () => setModalData(null);

  const handleSubmit = async (formData) => {
    let success;
    if (modalData?._id) {
      success = await updateContact(modalData._id, formData);
    } else {
      success = await createContact(formData);
    }
    if (success) closeModal();  // Only close if API call succeeded
  };

  return (
    <div className="page">
      {/* ── Header ── */}
      <header className="page-header">
        <div>
          <h1 className="page-title">Contacts</h1>
          <p className="page-sub">{contacts.length} contact{contacts.length !== 1 ? 's' : ''}</p>
        </div>
        <button className="btn-add" onClick={openAdd}>+ Add Contact</button>
      </header>

      {/* ── Loading / Empty / Grid ── */}
      {loading ? (
        <div className="state-msg">Loading contacts...</div>
      ) : contacts.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">👥</div>
          <h3>No contacts yet</h3>
          <p>Click <strong>+ Add Contact</strong> to get started.</p>
        </div>
      ) : (
        <div className="cards-grid">
          {contacts.map(c => (
            <ContactCard
              key={c._id}
              contact={c}
              onEdit={openEdit}
              onDelete={deleteContact}
            />
          ))}
        </div>
      )}

      {/* ── Modal Overlay ── */}
      {isModalOpen && (
        <div className="modal-overlay" onClick={closeModal}>
          <div className="modal-box" onClick={e => e.stopPropagation()}>
            <ContactForm
              initialData={modalData}
              onSubmit={handleSubmit}
              onCancel={closeModal}
              loading={saving}
              serverErrors={serverErrors}
            />
          </div>
        </div>
      )}
    </div>
  );
}